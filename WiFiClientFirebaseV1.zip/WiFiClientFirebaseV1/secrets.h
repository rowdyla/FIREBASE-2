// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "rowdyla91"                                // replace MySSID with your WiFi network name
#define SECRET_PASS "EsanMike98"                            // replace MyPassword with your WiFi password

#define FIREBASE_HOST "https://csc230sp22class-default-rtdb.firebaseio.com"
#define FIREBASE_AUTU "A7hI2JhrezTBYSFiHDcBOwFMl69NTNVuGvFtgHbT"
